import { useState, useRef, useCallback } from "react";

const STAGES = [
  { id: "prospecto",  label: "Prospecto",       color: "#8892B0" },
  { id: "contato",    label: "1º Contato",       color: "#38BDF8" },
  { id: "demo",       label: "Demo / Piloto",    color: "#818CF8" },
  { id: "proposta",   label: "Proposta Enviada", color: "#F59E0B" },
  { id: "negociacao", label: "Negociação",       color: "#F97316" },
  { id: "fechado",    label: "Fechado ✓",        color: "#22C55E" },
];

const SEED = [
  { id: 1, nome: "Casas Bahia",   contato: "—", stage: "demo",      notas: "Instalação confirmada. Piloto ativo.",      proximoPasso: "Acompanhar métricas do piloto", updatedAt: "2026-05-10" },
  { id: 2, nome: "Magalu",        contato: "—", stage: "contato",   notas: "Interesse verbal confirmado.",              proximoPasso: "Agendar demo",                  updatedAt: "2026-05-10" },
  { id: 3, nome: "Centauro",      contato: "—", stage: "prospecto", notas: "Mencionado como potencial cliente.",        proximoPasso: "Primeiro contato",             updatedAt: "2026-05-10" },
  { id: 4, nome: "Renner",        contato: "—", stage: "contato",   notas: "Conversa inicial realizada.",               proximoPasso: "Enviar material",              updatedAt: "2026-05-10" },
  { id: 5, nome: "Raia Drogasil", contato: "—", stage: "prospecto", notas: "Pipeline Latam identificado.",             proximoPasso: "Mapear contato certo",         updatedAt: "2026-05-10" },
  { id: 6, nome: "Havan",         contato: "—", stage: "prospecto", notas: "Cliente potencial varejo.",                proximoPasso: "Primeiro contato",             updatedAt: "2026-05-10" },
];

function stageInfo(id) { return STAGES.find(s => s.id === id) || STAGES[0]; }

function StageBadge({ stageId, small }) {
  const s = stageInfo(stageId);
  return (
    <span style={{
      background: s.color + "22", color: s.color,
      border: `1px solid ${s.color}44`,
      borderRadius: 20, padding: small ? "2px 8px" : "4px 12px",
      fontSize: small ? 10 : 11, fontWeight: 600, letterSpacing: "0.03em", whiteSpace: "nowrap",
    }}>{s.label}</span>
  );
}

function Avatar({ nome }) {
  const colors = ["#2952FF","#E8451A","#00D4FF","#F59E0B","#22C55E","#818CF8"];
  const c = colors[nome.charCodeAt(0) % colors.length];
  return (
    <div style={{ width: 36, height: 36, borderRadius: 10, background: c + "22", border: `1px solid ${c}44`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15, fontWeight: 800, color: c, flexShrink: 0 }}>
      {nome[0]}
    </div>
  );
}

function WaveBars({ active }) {
  const heights = [5,10,7,14,9,18,11,16,8,13,6,10,15,7,12];
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 2, height: 22 }}>
      {heights.map((h, i) => (
        <div key={i} style={{
          width: 2.5, height: active ? h : 4, borderRadius: 2,
          background: active ? "#E8451A" : "#2952FF",
          opacity: active ? 0.85 : 0.35,
          transition: "height 0.15s ease",
          animationName: active ? "wavePulse" : "none",
          animationDuration: `${0.4 + (i % 4) * 0.1}s`,
          animationIterationCount: "infinite",
          animationDirection: "alternate",
          animationTimingFunction: "ease-in-out",
          animationDelay: `${i * 0.05}s`,
        }} />
      ))}
    </div>
  );
}

const EMPTY_FORM = { nome: "", contato: "", stage: "prospecto", notas: "", proximoPasso: "" };

export default function KolCRM() {
  const [contacts, setContacts] = useState(() => {
    try {
      const saved = localStorage.getItem("kol-crm-contacts");
      return saved ? JSON.parse(saved) : SEED;
    } catch { return SEED; }
  });
  const [filterStage, setFilterStage] = useState("all");
  const [recording, setRecording] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [voiceErr, setVoiceErr] = useState("");
  const [selected, setSelected] = useState(null);
  const [editData, setEditData] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [activeField, setActiveField] = useState(null); // which field is recording
  const [search, setSearch] = useState("");
  const [toast, setToast] = useState("");
  const recognitionRef = useRef(null);
  const nextId = useRef(200);

  const saveContacts = (updated) => {
    setContacts(updated);
    try { localStorage.setItem("kol-crm-contacts", JSON.stringify(updated)); } catch {}
  };

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(""), 3000); };

  // Generic voice recorder that fills a target setter
  const startVoiceFor = useCallback((fieldSetter, fieldName) => {
    setVoiceErr("");
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { setVoiceErr("Use Safari (iPhone) ou Chrome (Android) para voz."); return; }
    if (recognitionRef.current) { recognitionRef.current.stop(); }

    const r = new SR();
    r.lang = "pt-BR"; r.continuous = true; r.interimResults = true;
    let final = "";
    r.onresult = e => {
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) final += e.results[i][0].transcript + " ";
        else interim += e.results[i][0].transcript;
      }
      fieldSetter((final + interim).trim());
    };
    r.onerror = e => { setVoiceErr("Erro: " + e.error); setRecording(false); setActiveField(null); };
    r.onend = () => { setRecording(false); setActiveField(null); };
    recognitionRef.current = r;
    r.start();
    setRecording(true);
    setActiveField(fieldName);
  }, []);

  const stopVoice = useCallback(() => {
    recognitionRef.current?.stop();
    recognitionRef.current = null;
    setRecording(false);
    setActiveField(null);
  }, []);

  const openNewForm = () => {
    setForm(EMPTY_FORM);
    setShowForm(true);
    setSelected(null);
  };

  const submitForm = () => {
    if (!form.nome.trim()) { setVoiceErr("Nome da empresa é obrigatório."); return; }
    const today = new Date().toISOString().slice(0, 10);
    const idx = contacts.findIndex(c => c.nome.toLowerCase() === form.nome.toLowerCase());
    let updated;
    if (idx !== -1) {
      updated = [...contacts];
      updated[idx] = { ...updated[idx], ...form, updatedAt: today };
      showToast(`✓ ${form.nome} atualizado`);
    } else {
      updated = [...contacts, { id: nextId.current++, ...form, updatedAt: today }];
      showToast(`✓ ${form.nome} adicionado`);
    }
    saveContacts(updated);
    setShowForm(false);
    setForm(EMPTY_FORM);
    setVoiceErr("");
  };

  const openEdit = (c) => { setEditData({ ...c }); };

  const saveEdit = () => {
    const updated = contacts.map(c => c.id === editData.id ? { ...editData, updatedAt: new Date().toISOString().slice(0, 10) } : c);
    saveContacts(updated);
    setSelected(editData);
    setEditData(null);
    showToast("✓ Salvo");
  };

  const deleteContact = (id) => {
    saveContacts(contacts.filter(c => c.id !== id));
    setSelected(null); setEditData(null);
    showToast("Contato removido");
  };

  const filtered = contacts
    .filter(c => filterStage === "all" || c.stage === filterStage)
    .filter(c => !search || c.nome.toLowerCase().includes(search.toLowerCase()) || (c.notas || "").toLowerCase().includes(search.toLowerCase()));

  const counts = {};
  STAGES.forEach(s => { counts[s.id] = contacts.filter(c => c.stage === s.id).length; });

  // Voice mic button for a field
  const MicBtn = ({ fieldKey, value, onChange }) => {
    const isActive = activeField === fieldKey && recording;
    return (
      <div style={{ display: "flex", gap: 6, alignItems: "flex-start" }}>
        {fieldKey === "notas" ? (
          <textarea className="inp" value={value} onChange={e => onChange(e.target.value)}
            placeholder={fieldKey === "notas" ? "O que foi discutido..." : ""}
            style={{ resize: "vertical", minHeight: 64, flex: 1 }} />
        ) : (
          <input className="inp" value={value} onChange={e => onChange(e.target.value)} style={{ flex: 1 }} />
        )}
        <button
          onMouseDown={() => isActive ? stopVoice() : startVoiceFor(onChange, fieldKey)}
          style={{
            width: 34, height: 34, borderRadius: 8, border: "none", cursor: "pointer", flexShrink: 0, marginTop: 1,
            background: isActive ? "#E8451A22" : "#2952FF22",
            color: isActive ? "#E8451A" : "#2952FF",
            fontSize: 15, display: "flex", alignItems: "center", justifyContent: "center",
            transition: "all 0.15s",
          }}>
          {isActive ? "⏹" : "🎙"}
        </button>
      </div>
    );
  };

  const css = `
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body { height: 100%; background: #080C1E; font-family: 'Plus Jakarta Sans', sans-serif; color: #fff; }
    ::-webkit-scrollbar { width: 4px; }
    ::-webkit-scrollbar-track { background: #0F1530; }
    ::-webkit-scrollbar-thumb { background: #2952FF44; border-radius: 2px; }
    @keyframes wavePulse { from { transform: scaleY(0.5); } to { transform: scaleY(1.5); } }
    @keyframes fadeUp { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:translateY(0); } }
    @keyframes slideIn { from { opacity:0; transform:translateX(16px); } to { opacity:1; transform:translateX(0); } }
    @keyframes modalIn { from { opacity:0; transform:scale(0.96) translateY(20px); } to { opacity:1; transform:scale(1) translateY(0); } }
    .card-item { animation: fadeUp 0.25s ease; transition: border-color 0.15s, transform 0.15s; }
    .card-item:hover { transform: translateY(-1px); }
    .inp { background: #080C1E; border: 1px solid #2952FF33; border-radius: 10px; padding: 9px 13px; color: #fff; font-size: 13px; font-family: 'Plus Jakarta Sans', sans-serif; outline: none; width: 100%; }
    .inp:focus { border-color: #2952FF88; }
    select.inp option { background: #141936; }
    .btn-blue { background: linear-gradient(135deg,#2952FF,#4B6FFF); color:#fff; border:none; border-radius:10px; padding:10px 18px; font-size:13px; font-weight:600; cursor:pointer; font-family:inherit; transition:all 0.2s; }
    .btn-blue:hover { box-shadow: 0 4px 16px #2952FF55; transform:translateY(-1px); }
    .btn-red { background: linear-gradient(135deg,#E8451A,#FF6B3D); color:#fff; border:none; border-radius:10px; padding:10px 18px; font-size:13px; font-weight:600; cursor:pointer; font-family:inherit; transition:all 0.2s; display:flex; align-items:center; gap:8px; }
    .btn-red:hover { box-shadow: 0 4px 16px #E8451A55; transform:translateY(-1px); }
    .btn-ghost { background:transparent; color:#8892B0; border:1px solid #8892B033; border-radius:10px; padding:9px 16px; font-size:12px; font-weight:500; cursor:pointer; font-family:inherit; transition:all 0.2s; }
    .btn-ghost:hover { border-color:#2952FF66; color:#fff; }
    .label { font-size: 10px; color: #8892B0; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 5px; }
  `;

  const FormPanel = ({ data, setData, onSubmit, onCancel, title }) => (
    <div style={{ position: "fixed", inset: 0, background: "#00000099", display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 200, backdropFilter: "blur(6px)" }}>
      <div style={{ background: "#141936", border: "1px solid #2952FF33", borderRadius: "20px 20px 0 0", padding: "24px 20px 36px", width: "100%", maxWidth: 480, maxHeight: "90vh", overflowY: "auto", animation: "modalIn 0.25s ease" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div style={{ fontSize: 16, fontWeight: 800 }}>{title}</div>
          <button onClick={onCancel} style={{ background: "none", border: "none", color: "#8892B0", cursor: "pointer", fontSize: 22 }}>×</button>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div>
            <div className="label">Empresa *</div>
            <MicBtn fieldKey="nome" value={data.nome} onChange={v => setData(p => ({...p, nome: v}))} />
          </div>
          <div>
            <div className="label">Contato</div>
            <MicBtn fieldKey="contato" value={data.contato} onChange={v => setData(p => ({...p, contato: v}))} />
          </div>
          <div>
            <div className="label">Fase</div>
            <select className="inp" value={data.stage} onChange={e => setData(p => ({...p, stage: e.target.value}))}>
              {STAGES.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
            </select>
          </div>
          <div>
            <div className="label">Notas — o que foi discutido</div>
            <MicBtn fieldKey="notas" value={data.notas} onChange={v => setData(p => ({...p, notas: v}))} />
          </div>
          <div>
            <div className="label">Próximo passo</div>
            <MicBtn fieldKey="proximoPasso" value={data.proximoPasso} onChange={v => setData(p => ({...p, proximoPasso: v}))} />
          </div>
        </div>

        {voiceErr && <div style={{ marginTop: 10, fontSize: 11, color: "#E8451A" }}>{voiceErr}</div>}

        <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
          <button className="btn-blue" style={{ flex: 1 }} onClick={onSubmit}>Salvar</button>
          <button className="btn-ghost" onClick={onCancel}>Cancelar</button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      <style>{css}</style>
      <div style={{ height: "100vh", display: "flex", flexDirection: "column", background: "#080C1E", overflow: "hidden" }}>

        {/* Header */}
        <div style={{ background: "#0F1530", borderBottom: "1px solid #2952FF22", padding: "14px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: "-0.02em", background: "linear-gradient(135deg,#4B6FFF,#2952FF)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>kol</div>
            <div style={{ width: 1, height: 18, background: "#2952FF33" }} />
            <div style={{ fontSize: 11, color: "#8892B0", fontWeight: 500 }}>Pipeline de Clientes</div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <WaveBars active={recording} />
            <button className="btn-red" style={{ padding: "7px 14px", fontSize: 12 }} onClick={openNewForm}>
              + Nova nota
            </button>
          </div>
        </div>

        <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>

          {/* Sidebar */}
          <div style={{ width: 190, background: "#0F1530", borderRight: "1px solid #2952FF1A", padding: "14px 8px", display: "flex", flexDirection: "column", gap: 3, flexShrink: 0, overflowY: "auto" }}>
            <div style={{ fontSize: 10, color: "#8892B0", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 6, paddingLeft: 8 }}>Fase</div>
            {[{ id: "all", label: "Todos", color: "#2952FF" }, ...STAGES].map(s => {
              const count = s.id === "all" ? contacts.length : (counts[s.id] || 0);
              const active = filterStage === s.id;
              return (
                <button key={s.id} onClick={() => setFilterStage(s.id)} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "8px 10px", borderRadius: 8, border: "none", background: active ? s.color + "1A" : "transparent", color: active ? s.color : "#8892B0", cursor: "pointer", fontSize: 12, fontWeight: active ? 700 : 400, fontFamily: "inherit", transition: "all 0.15s", textAlign: "left", width: "100%" }}>
                  <span>{s.label}</span>
                  <span style={{ background: active ? s.color + "2A" : "#ffffff0A", color: active ? s.color : "#8892B0", borderRadius: 10, padding: "1px 7px", fontSize: 10, fontWeight: 700 }}>{count}</span>
                </button>
              );
            })}
          </div>

          {/* Main list */}
          <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
            <div style={{ padding: "12px 16px", borderBottom: "1px solid #2952FF1A", flexShrink: 0 }}>
              <input className="inp" placeholder="🔍  buscar empresa ou nota..." value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            <div style={{ flex: 1, overflowY: "auto", padding: "12px 16px", display: "flex", flexDirection: "column", gap: 8 }}>
              {filtered.length === 0 && (
                <div style={{ textAlign: "center", color: "#8892B0", padding: 48, fontSize: 13 }}>
                  {search ? `Nenhum resultado para "${search}"` : "Nenhuma empresa nesta fase."}
                </div>
              )}
              {filtered.map(c => {
                const isSel = selected?.id === c.id;
                return (
                  <div key={c.id} className="card-item" onClick={() => setSelected(isSel ? null : c)}
                    style={{ background: "#141936", border: `1px solid ${isSel ? "#2952FF66" : "#2952FF1A"}`, borderRadius: 12, padding: "13px 16px", cursor: "pointer" }}>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0 }}>
                        <Avatar nome={c.nome} />
                        <div style={{ minWidth: 0 }}>
                          <div style={{ fontWeight: 700, fontSize: 14, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{c.nome}</div>
                          {c.contato && c.contato !== "—" && <div style={{ fontSize: 11, color: "#8892B0" }}>{c.contato}</div>}
                        </div>
                      </div>
                      <StageBadge stageId={c.stage} small />
                    </div>
                    {c.proximoPasso && (
                      <div style={{ marginTop: 8, fontSize: 11, color: "#00D4FF", background: "#00D4FF11", borderRadius: 6, padding: "4px 10px", display: "inline-block" }}>
                        → {c.proximoPasso}
                      </div>
                    )}
                    <div style={{ fontSize: 10, color: "#8892B044", marginTop: 6 }}>{c.updatedAt}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Detail panel */}
          {selected && !showForm && !editData && (
            <div style={{ width: 280, background: "#0F1530", borderLeft: "1px solid #2952FF1A", padding: 18, overflowY: "auto", flexShrink: 0, animation: "slideIn 0.2s ease" }}>
              <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 14 }}>
                <div>
                  <div style={{ fontSize: 17, fontWeight: 800 }}>{selected.nome}</div>
                  <div style={{ marginTop: 6 }}><StageBadge stageId={selected.stage} /></div>
                </div>
                <button onClick={() => setSelected(null)} style={{ background: "none", border: "none", color: "#8892B0", cursor: "pointer", fontSize: 20 }}>×</button>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                {selected.contato && selected.contato !== "—" && (
                  <div><div className="label">Contato</div><div style={{ fontSize: 13, color: "#CDD6F4" }}>{selected.contato}</div></div>
                )}
                {selected.notas && (
                  <div><div className="label">Notas</div><div style={{ fontSize: 13, color: "#CDD6F4", lineHeight: 1.6 }}>{selected.notas}</div></div>
                )}
                {selected.proximoPasso && (
                  <div><div className="label" style={{ color: "#00D4FF" }}>Próximo passo</div><div style={{ fontSize: 13, color: "#00D4FF", lineHeight: 1.6 }}>{selected.proximoPasso}</div></div>
                )}
                <div style={{ fontSize: 10, color: "#8892B033" }}>Atualizado: {selected.updatedAt}</div>
              </div>
              <div style={{ display: "flex", gap: 8, marginTop: 18 }}>
                <button className="btn-blue" style={{ flex: 1, padding: "9px 0", fontSize: 12 }} onClick={() => openEdit(selected)}>Editar</button>
                <button className="btn-ghost" style={{ padding: "9px 12px", fontSize: 12, color: "#ef4444", borderColor: "#ef444433" }} onClick={() => deleteContact(selected.id)}>✕</button>
              </div>
            </div>
          )}
        </div>

        {/* New entry form */}
        {showForm && (
          <FormPanel
            title="Nova nota de cliente"
            data={form}
            setData={setForm}
            onSubmit={submitForm}
            onCancel={() => { setShowForm(false); setVoiceErr(""); stopVoice(); }}
          />
        )}

        {/* Edit form */}
        {editData && (
          <FormPanel
            title={`Editar — ${editData.nome}`}
            data={editData}
            setData={setEditData}
            onSubmit={saveEdit}
            onCancel={() => { setEditData(null); setVoiceErr(""); stopVoice(); }}
          />
        )}

        {/* Toast */}
        {toast && (
          <div style={{ position: "fixed", bottom: 24, right: 24, background: "#2952FF", color: "#fff", borderRadius: 10, padding: "10px 18px", fontSize: 13, fontWeight: 600, zIndex: 300, boxShadow: "0 4px 20px #2952FF55", animation: "fadeUp 0.2s ease" }}>
            {toast}
          </div>
        )}
      </div>
    </>
  );
}
